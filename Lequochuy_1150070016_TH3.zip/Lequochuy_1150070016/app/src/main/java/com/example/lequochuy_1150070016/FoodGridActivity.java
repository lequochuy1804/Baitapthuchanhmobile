package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodGridActivity extends AppCompatActivity {

    private GridView gridFood;
    private TextView txtSelectedGridFood;
    private ArrayList<Food> foodList;
    private FoodGridAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_grid);
        setTitle("Grid món ăn");

        gridFood = findViewById(R.id.gridFood);
        txtSelectedGridFood = findViewById(R.id.txtSelectedGridFood);

        foodList = new ArrayList<>();
        foodList.add(new Food(R.drawable.mon_pho, "Phở bò", "Bánh phở với thịt bò"));
        foodList.add(new Food(R.drawable.mon_buncha, "Bún chả", "Bún với chả nướng"));
        foodList.add(new Food(R.drawable.mon_comtam, "Cơm tấm", "Cơm tấm sườn bì chả"));
        foodList.add(new Food(R.drawable.mon_banhmi, "Bánh mì", "Bánh mì thịt"));
        foodList.add(new Food(R.drawable.mon_goicuon, "Gỏi cuốn", "Bánh tráng cuốn tôm thịt"));

        adapter = new FoodGridAdapter(this, R.layout.item_food_grid, foodList);
        gridFood.setAdapter(adapter);

        gridFood.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Food f = foodList.get(position);
                String info = f.getName() + " - " + f.getDescription();
                txtSelectedGridFood.setText(info);
            }
        });
    }
}
