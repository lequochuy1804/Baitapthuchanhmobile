package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class ColorActivity extends AppCompatActivity {

    private SeekBar seekR, seekG, seekB;
    private TextView txtRValue, txtGValue, txtBValue;
    private View viewRgb, viewCmy;

    private int r = 0, g = 0, b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);
        setTitle("ChooseColor");

        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);
        txtRValue = findViewById(R.id.txtRValue);
        txtGValue = findViewById(R.id.txtGValue);
        txtBValue = findViewById(R.id.txtBValue);
        viewRgb = findViewById(R.id.viewRgb);
        viewCmy = findViewById(R.id.viewCmy);

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (seekBar == seekR) {
                    r = progress;
                } else if (seekBar == seekG) {
                    g = progress;
                } else if (seekBar == seekB) {
                    b = progress;
                }
                updateColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };

        seekR.setOnSeekBarChangeListener(listener);
        seekG.setOnSeekBarChangeListener(listener);
        seekB.setOnSeekBarChangeListener(listener);

        updateColor();
    }

    private void updateColor() {
        txtRValue.setText("R = " + r);
        txtGValue.setText("G = " + g);
        txtBValue.setText("B = " + b);

        int rgbColor = Color.rgb(r, g, b);
        viewRgb.setBackgroundColor(rgbColor);

        int c = 255 - r;
        int m = 255 - g;
        int y = 255 - b;
        int cmyColor = Color.rgb(c, m, y);
        viewCmy.setBackgroundColor(cmyColor);
    }
}
