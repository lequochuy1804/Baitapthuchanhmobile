package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodListActivity extends AppCompatActivity {

    private ListView lvFood;
    private TextView txtSelectedFood;
    private ArrayList<Food> foodList;
    private FoodAdapter adapter;
    private int selectedPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);
        setTitle("Danh sách món ăn");

        lvFood = findViewById(R.id.lvFood);
        txtSelectedFood = findViewById(R.id.txtSelectedFood);

        foodList = new ArrayList<>();
        foodList.add(new Food(R.drawable.mon_pho, "Phở bò", "Bánh phở với thịt bò"));
        foodList.add(new Food(R.drawable.mon_buncha, "Bún chả", "Bún với chả nướng"));
        foodList.add(new Food(R.drawable.mon_comtam, "Cơm tấm", "Cơm tấm sườn bì chả"));
        foodList.add(new Food(R.drawable.mon_banhmi, "Bánh mì", "Bánh mì thịt"));
        foodList.add(new Food(R.drawable.mon_goicuon, "Gỏi cuốn", "Bánh tráng cuốn tôm thịt"));

        adapter = new FoodAdapter(this, R.layout.item_food, foodList);
        lvFood.setAdapter(adapter);

        lvFood.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Food f = foodList.get(position);
                String info = f.getName() + " - " + f.getDescription();
                txtSelectedFood.setText(info);
                selectedPosition = position;
            }
        });

        registerForContextMenu(lvFood);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_food_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_add_food) {
            showAddFoodDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu_food_context, menu);
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        selectedPosition = info.position;
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (selectedPosition < 0 || selectedPosition >= foodList.size()) {
            return super.onContextItemSelected(item);
        }

        int id = item.getItemId();
        if (id == R.id.menu_edit_food) {
            showEditFoodDialog(selectedPosition);
            return true;
        } else if (id == R.id.menu_delete_food) {
            foodList.remove(selectedPosition);
            adapter.notifyDataSetChanged();
            txtSelectedFood.setText("Chọn một món ăn...");
            selectedPosition = -1;
            return true;
        }

        return super.onContextItemSelected(item);
    }

    private void showAddFoodDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_food, null);
        final EditText edtName = view.findViewById(R.id.edtFoodName);
        final EditText edtDesc = view.findViewById(R.id.edtFoodDesc);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Thêm món ăn");
        builder.setView(view);
        builder.setPositiveButton("Lưu", (dialog, which) -> {
            String name = edtName.getText().toString().trim();
            String desc = edtDesc.getText().toString().trim();
            if (!name.isEmpty()) {
                Food f = new Food(R.drawable.mon_pho, name, desc);
                foodList.add(f);
                adapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("Huỷ", null);
        builder.show();
    }

    private void showEditFoodDialog(int position) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_food, null);
        final EditText edtName = view.findViewById(R.id.edtFoodName);
        final EditText edtDesc = view.findViewById(R.id.edtFoodDesc);

        Food old = foodList.get(position);
        edtName.setText(old.getName());
        edtDesc.setText(old.getDescription());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Sửa món ăn");
        builder.setView(view);
        builder.setPositiveButton("Lưu", (dialog, which) -> {
            String name = edtName.getText().toString().trim();
            String desc = edtDesc.getText().toString().trim();
            if (!name.isEmpty()) {
                Food f = new Food(old.getImageResId(), name, desc);
                foodList.set(position, f);
                adapter.notifyDataSetChanged();
                String info = f.getName() + " - " + f.getDescription();
                txtSelectedFood.setText(info);
            }
        });
        builder.setNegativeButton("Huỷ", null);
        builder.show();
    }
}
