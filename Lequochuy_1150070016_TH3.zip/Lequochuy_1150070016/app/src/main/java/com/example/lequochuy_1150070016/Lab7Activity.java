package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Lab7Activity extends AppCompatActivity {

    private Button btnColoredSelector;
    private Button btnColoredDisabled;
    private Button btnRoundShape;
    private Button btnGradientShape;
    private Button btnSelectorShape;
    private Button btnFaceLeftTop;
    private Button btnFaceLeftBottom;
    private Button btnFaceRight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab7);
        setTitle("DrawableExample");

        btnColoredSelector = findViewById(R.id.btnColoredSelector);
        btnColoredDisabled = findViewById(R.id.btnColoredDisabled);
        btnRoundShape = findViewById(R.id.btnRoundShape);
        btnGradientShape = findViewById(R.id.btnGradientShape);
        btnSelectorShape = findViewById(R.id.btnSelectorShape);
        btnFaceLeftTop = findViewById(R.id.btnFaceLeftTop);
        btnFaceLeftBottom = findViewById(R.id.btnFaceLeftBottom);
        btnFaceRight = findViewById(R.id.btnFaceRight);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                String text = "Bạn nhấn: " + b.getText();
                Toast.makeText(Lab7Activity.this, text, Toast.LENGTH_SHORT).show();
            }
        };

        btnColoredSelector.setOnClickListener(listener);
        btnRoundShape.setOnClickListener(listener);
        btnGradientShape.setOnClickListener(listener);
        btnSelectorShape.setOnClickListener(listener);
        btnFaceLeftTop.setOnClickListener(listener);
        btnFaceLeftBottom.setOnClickListener(listener);
        btnFaceRight.setOnClickListener(listener);
    }
}
