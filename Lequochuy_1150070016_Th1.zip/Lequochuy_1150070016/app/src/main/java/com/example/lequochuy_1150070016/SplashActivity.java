package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.Random;

public class SplashActivity extends AppCompatActivity {

    LinearLayout rootSplash;
    ImageView imgAnimal;
    View viewLoading;

    int[] bgColors = {
            R.color.splash_1,
            R.color.splash_2,
            R.color.splash_3,
            R.color.splash_4
    };

    int[] animalIcons = {
            R.drawable.ic_penguin,
            R.drawable.ic_cat,
            R.drawable.ic_dog,
            R.drawable.ic_lion
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // ánh xạ
        viewLoading = findViewById(R.id.viewLoading);
        rootSplash = findViewById(R.id.rootSplash);
        imgAnimal = findViewById(R.id.imgAnimal);

        // ====== phần bài 1: random màu + icon ======
        Random random = new Random();

        int colorIndex = random.nextInt(bgColors.length);
        rootSplash.setBackgroundColor(getResources().getColor(bgColors[colorIndex]));

        int iconIndex = random.nextInt(animalIcons.length);
        imgAnimal.setImageResource(animalIcons[iconIndex]);

        // ====== phần bài 3: bấm vào icon để gọi điện ======
        imgAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // số điện thoại muốn gọi
                String phone = "0909123456"; // m đổi số này theo ý m

                // tạo intent mở màn hình gọi
                Intent intent = new Intent(Intent.ACTION_DIAL,
                        Uri.parse("tel:" + phone));

                // chạy intent
                startActivity(intent);
            }
        });
    }
}
