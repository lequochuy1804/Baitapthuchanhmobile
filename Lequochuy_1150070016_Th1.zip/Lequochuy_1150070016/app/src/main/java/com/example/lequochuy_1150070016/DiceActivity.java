package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class DiceActivity extends AppCompatActivity {

    TextView txtNumber;
    Button btnRandom, btnRoll;
    ImageView imgDice;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dice);

        txtNumber = findViewById(R.id.txtNumber);
        btnRandom = findViewById(R.id.btnRandom);
        btnRoll = findViewById(R.id.btnRoll);
        imgDice = findViewById(R.id.imgDice);

        btnRandom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int face = random.nextInt(6) + 1;
                txtNumber.setText(String.valueOf(face));
                showFace(face);
            }
        });

        btnRoll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int face = random.nextInt(6) + 1;
                txtNumber.setText(String.valueOf(face));
                showFace(face);
            }
        });
    }

    private void showFace(int face) {
        switch (face) {
            case 1:
                imgDice.setImageResource(R.drawable.dice1);
                break;
            case 2:
                imgDice.setImageResource(R.drawable.dice2);
                break;
            case 3:
                imgDice.setImageResource(R.drawable.dice3);
                break;
            case 4:
                imgDice.setImageResource(R.drawable.dice4);
                break;
            case 5:
                imgDice.setImageResource(R.drawable.dice5);
                break;
            case 6:
                imgDice.setImageResource(R.drawable.dice6);
                break;
        }
    }
}
