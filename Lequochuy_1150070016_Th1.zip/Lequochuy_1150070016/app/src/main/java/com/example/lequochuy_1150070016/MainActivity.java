package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edtSo1, edtSo2;
    TextView tvKetQua;
    Button btnCong, btnTru, btnNhan, btnChia, btnMod;
    Button btnDice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initControl();
        initEvent();
    }

    private void initControl() {
        edtSo1 = findViewById(R.id.edtSo1);
        edtSo2 = findViewById(R.id.edtSo2);
        tvKetQua = findViewById(R.id.tvKetQua);
        btnCong = findViewById(R.id.btnCong);
        btnTru = findViewById(R.id.btnTru);
        btnNhan = findViewById(R.id.btnNhan);
        btnChia = findViewById(R.id.btnChia);
        btnMod = findViewById(R.id.btnMod);

        btnDice = findViewById(R.id.btnDice);
    }

    private void initEvent() {
        btnCong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinh("+");
            }
        });
        btnTru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinh("-");
            }
        });
        btnNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinh("*");
            }
        });
        btnChia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinh("/");
            }
        });
        btnMod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinh("%");
            }
        });
        Button btnProfile = findViewById(R.id.btnProfile);
        btnProfile.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ProfileActivity.class));
        });

        Button btnPhone = findViewById(R.id.btnPhone);
        btnPhone.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, PhoneActivity.class);
            startActivity(i);
        });
        btnDice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, DiceActivity.class);
                startActivity(i);
            }
        });
    }

    private void tinh(String op) {
        String s1 = edtSo1.getText().toString().trim();
        String s2 = edtSo2.getText().toString().trim();
        if (s1.isEmpty() || s2.isEmpty()) {
            tvKetQua.setText("Nhập đủ số");
            return;
        }
        double a = Double.parseDouble(s1);
        double b = Double.parseDouble(s2);
        double kq = 0;
        if (op.equals("+")) kq = a + b;
        else if (op.equals("-")) kq = a - b;
        else if (op.equals("*")) kq = a * b;
        else if (op.equals("/")) {
            if (b == 0) {
                tvKetQua.setText("Không chia được");
                return;
            }
            kq = a / b;
        } else if (op.equals("%")) {
            if (b == 0) {
                tvKetQua.setText("Không chia được");
                return;
            }
            kq = a % b;
        }
        tvKetQua.setText(String.valueOf(kq));
    }
}
