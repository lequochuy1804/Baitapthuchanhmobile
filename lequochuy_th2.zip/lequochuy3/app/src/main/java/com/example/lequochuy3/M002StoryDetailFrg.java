package com.example.lequochuy3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class M002StoryDetailFrg extends Fragment {

    private static final String KEY_NAME = "key_name";

    public static M002StoryDetailFrg newInstance(String name) {
        M002StoryDetailFrg frg = new M002StoryDetailFrg();
        Bundle b = new Bundle();
        b.putString(KEY_NAME, name);
        frg.setArguments(b);
        return frg;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.m002_frg_story_detail, container, false);
        TextView tvTitle = v.findViewById(R.id.tvStoryTitle);
        TextView tvContent = v.findViewById(R.id.tvStoryContent);
        TextView tvBack = v.findViewById(R.id.tvBack);

        String name = getArguments() != null ? getArguments().getString(KEY_NAME) : "";
        tvTitle.setText(name);
        tvContent.setText(getContent(name));

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) requireActivity()).backToM001Screen();
            }
        });

        return v;
    }

    private String getContent(String name) {
        if ("Bác sĩ và bệnh nhân".equals(name)) {
            return "Bệnh nhân nói mình xấu.\nBác sĩ nói do hoa mắt.";
        } else if ("Vova đi học".equals(name)) {
            return "Cô hỏi 1+1.\nVova trả lời 2.\nCô khen.";
        } else if ("Con gà và quả trứng".equals(name)) {
            return "Hai vợ chồng cãi nhau con gì có trước.\nCuối cùng vẫn ăn trứng chiên.";
        }
        return "Chưa có nội dung.";
    }
}
