package com.example.lequochuy3;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RabbitActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m003_act_detail);

        Button btnOn = findViewById(R.id.btnOn);
        Button btnOff = findViewById(R.id.btnOff);

        btnOn.setOnClickListener(v ->
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR));

        btnOff.setOnClickListener(v ->
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));
    }
}
