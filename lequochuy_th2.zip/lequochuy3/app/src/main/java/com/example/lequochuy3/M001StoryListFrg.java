package com.example.lequochuy3;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

public class M001StoryListFrg extends Fragment {

    private String[] names = {
            "Bác sĩ và bệnh nhân",
            "Vova đi học",
            "Con gà và quả trứng",
            "Xem màn con thỏ",
            "Màn đa ngôn ngữ",
            "Màn login"
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.m001_frg_story_list, container, false);
        ListView lv = v.findViewById(R.id.lvStory);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, names);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 3) {
                    startActivity(new Intent(requireContext(), RabbitActivity.class));
                } else if (position == 4) {
                    startActivity(new Intent(requireContext(), MultiLangActivity.class));
                } else if (position == 5) {
                    startActivity(new Intent(requireContext(), LoginActivity.class));
                } else {
                    ((MainActivity) requireActivity()).gotoM002Screen(names[position]);
                }
            }
        });

        return v;
    }
}
