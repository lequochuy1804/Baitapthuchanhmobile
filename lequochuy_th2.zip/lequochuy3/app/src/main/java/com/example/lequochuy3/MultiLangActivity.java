package com.example.lequochuy3;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MultiLangActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_lang);

        TextView tvVi = findViewById(R.id.tvVi);
        TextView tvEn = findViewById(R.id.tvEn);
        TextView tvFr = findViewById(R.id.tvFr);

        tvVi.setOnClickListener(v -> setLocale("vi"));
        tvEn.setOnClickListener(v -> setLocale("en"));
        tvFr.setOnClickListener(v -> setLocale("fr"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_language, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mn_vi) {
            setLocale("vi");
            return true;
        } else if (id == R.id.mn_en) {
            setLocale("en");
            return true;
        } else if (id == R.id.mn_fr) {
            setLocale("fr");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
        Intent i = new Intent(this, MultiLangActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}
