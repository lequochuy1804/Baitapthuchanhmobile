package com.example.lequochuy3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showFrg(new M000SplashFrg());
    }

    private void showFrg(Fragment frg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null)
                .commit();
    }

    public void gotoM001Screen() {
        showFrg(new M001StoryListFrg());
    }

    public void gotoM002Screen(String topicName) {
        showFrg(M002StoryDetailFrg.newInstance(topicName));
    }

    public void backToM001Screen() {
        gotoM001Screen();
    }
}
